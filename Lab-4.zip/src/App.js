
import './App.css';
import { BrowserRouter as Router, Route, Link, Routes } from 'react-router-dom';


import Home from './Components/Home'
import CharactersPage from './Components/CharactersPage'
import CharacterPage from './Components/CharacterPage';
import ComicsPage from './Components/ComicsPage';
import ComicPage from './Components/ComicPage';
import SeriesPage from './Components/SeriesPage';
import SeriePage from './Components/SeriePage';
import ErrorPage from './Components/ErrorPage';

function App() {
  return (


    
   <Router>



<div className='App'>
    <Link className="showlink" to="/">Home</Link>
    &nbsp;&nbsp;
    <Link className="showlink" to="/characters/page/0">characters</Link>
    &nbsp;&nbsp;
    <Link className="showlink" to="/comics/page/0">comics</Link>
    &nbsp;&nbsp;
    <Link className="showlink" to="/series/page/0">series</Link>
          </div>

	   <div className='App-body'>
    <Routes>
    <Route path="/" element={<Home />}></Route>
	  <Route path="/characters/page/:page" element={<CharactersPage />}></Route>
    <Route path="/characters/:id" element={<CharacterPage />}></Route>
    <Route path="/comics/page/:page" element={<ComicsPage />}></Route>
    <Route path="/comics/:id" element={<ComicPage />}></Route>
    <Route path="/series/page/:page" element={<SeriesPage/>}></Route>
    <Route path="/series/:id" element={<SeriePage/>}></Route>
    <Route path='*' element={<ErrorPage/>} status={404} />
    </Routes>
	</div>
  </Router>
  );
}

export default App;
