

const Home= ()=>{



return(

  <div>
        
  <div className="intro" style={{display: 'flex',  justifyContent:'center', alignItems:'center', height: '50vh'}}>
    <br></br>
      <p>Marvel Universe is filled with many Characters Comics and Series. All these are layed out for you right here in this application, check it out...!</p>
  </div>
</div>

          
        )


        


}

export default Home