import Search from "./Search";
import ErrorPage from "./ErrorPage";




import { useParams,Link } from "react-router-dom";
import axios from 'axios';
import { Button } from "react-bootstrap";
const md5 = require('blueimp-md5');
const { useEffect, useState } = require('react');
const publickey = 'd9a23a6a20dedd3f5d3e5040c6fe4889';
const privatekey = '0165a5effa47fb323dd4c504349f2be30ad07a1e';
const ts = new Date().getTime();
const stringToHash = ts + privatekey + publickey;
const hash = md5(stringToHash);


const SeriesPage=()=>
{





    const[Data, setData]=useState(undefined)
    const [ searchTerm, setSearchTerm ] = useState('');
	const [ searchData, setSearchData ] = useState(undefined);
    const [ nextTerm,   setNextTerm ]  = useState(false)
	const [ previousTerm,  setPreviousTerm ]  = useState(false)
    const [checkPage, setcheckPage]= useState(false)
   

    let { page } = useParams()

    let listItems=null


useEffect(()=>{
   async function fetchData()
   {
    try{

        if( isNaN(page) || parseInt(page)<0)
        {
    
           setcheckPage(true)
        }
        else{

    const baseUrl = 'https://gateway.marvel.com:443/v1/public/series';
    const url = baseUrl + '?ts=' + ts + '&offset='+ parseInt(page*20)+ '&limit='+20 + '&apikey=' + publickey + '&hash=' + hash;


    const {data} = await axios.get(url)


    console.log(data.data.results)


    setData(data.data.results)


    if(parseInt(page)==0)
        {
            setNextTerm(true)
            setPreviousTerm(false)
        }
        else if(parseInt(page)==Math.ceil(data.data.total/20)-1)
        {
            setNextTerm(false)
            setPreviousTerm(true)
        }
        else
        {
            setNextTerm(true)
            setPreviousTerm(true) 
        }

    }
   }
    
    catch(e)
    {
        console.log(e)
    }
}  

   fetchData()
},[page])





useEffect(
    () => {
        console.log('search useEffect fired');
        async function fetchData() {
            try {
                const baseUrl = 'https://gateway.marvel.com:443/v1/public/series';
                const url = baseUrl + '?titleStartsWith='+searchTerm + '&limit='+20 +'&ts=' + ts   +'&apikey=' + publickey + '&hash=' + hash;
                const {data} = await axios.get(url)

                console.log(data.data.results)
                setSearchData(data.data.results);
                
            } catch (e) {
                console.log(e);
            }
        }
        if (searchTerm) {
            console.log ('searchTerm is set')
            fetchData();
        }
    },
    [ searchTerm ]
);

const searchValue = async (value) => {
    setSearchTerm(value);
};


    


if(Data==undefined && checkPage==false){


    return(<p>Loading....</p>)
}

else if(checkPage==true)
{
    return(<ErrorPage/>)
}

else if(searchTerm && searchData!=undefined)
{

    if(searchData.length>0)
    {
        listItems=searchData.map((series)=>
        <li key={series.id}>
          <Link aria-label={"More info when clicked"} to={`/series/${series.id}`}>{series.title}</Link>
        </li>)
    
    }

}

else if(Data.length>0)
{
     listItems=Data.map((series)=>
     <li key={series.id}>
       <Link aria-label={"More info when clicked"}to={`/series/${series.id}`}>{series.title}</Link>
     </li>)
}


else
{
    return(<ErrorPage/>)
}



return (
    <div>

<br></br> <br></br>

<p style={{fontSize:22}}><u>Series</u></p>
    
    <br></br> 
    
    <Search searchValue={searchValue} />

    <br></br>
    <ul>{listItems}</ul>


    <br></br>
				{
                   
				((Data.length>0) && nextTerm && searchTerm=='')?<Button as={Link} to={`/series/page/${parseInt(page)+1}`}>
					Next
				</Button>:null
				}
				&nbsp;&nbsp;&nbsp;
				{
				((Data.length>0)&&previousTerm  && searchTerm=='')?<Button as={Link} to={`/series/page/${parseInt(page)-1}`}>
					Previous
				</Button>:null
				}
         
    
    </div>
)




}


export default SeriesPage
