import { useParams,Link } from "react-router-dom"
import ErrorPage from "./ErrorPage";
import axios from 'axios';
const md5 = require('blueimp-md5');
const { useEffect, useState } = require('react');
const publickey = 'd9a23a6a20dedd3f5d3e5040c6fe4889';
const privatekey = '0165a5effa47fb323dd4c504349f2be30ad07a1e';
const ts = new Date().getTime();
const stringToHash = ts + privatekey + publickey;
const hash = md5(stringToHash);

const CharacterPage =()=>
{
    const[Data, setData]=useState(undefined)
    const[Error, setError]= useState(false)
    const [checkPage, setcheckPage]= useState(false)

    let {id}= useParams()

useEffect(()=>{

   async function fetchData()
   {
       try{

        if( isNaN(id) || parseInt(id)<0)
        {
    
           setcheckPage(true)
        }
        else{

                const baseUrl = 'https://gateway.marvel.com:443/v1/public/characters/';
                const url = baseUrl + id+'?ts=' + ts + '&apikey=' + publickey + '&hash=' + hash;

                const { data } = await axios.get(url)

                setData(data.data.results)
                setError(false)

        }

       }

       catch(e)
       {
            setError(true)

           console.log(e)
       }



   }

   fetchData()

},[id])




 if(Error || checkPage)
{
    return(<ErrorPage/>)
}

else if(Data!=undefined)
{


    let comicsList=Data[0].comics.items.map((items,index)=>{

    
        return( <li key={index}>
           <Link aria-label={"More info when clicked"} to={`/comics/${items.resourceURI.split('/')[6]}`}>{items.name}</Link>
         </li>)
         
     })


     const check={

        fontSize: 18
    }


    let description;
    let comics;
    let descHeading
    
    

    
    if(Data[0].description=='' || Data[0].description==null)
    {
        descHeading= <h3>Description: None</h3>
    }
    else
    {
        descHeading= <h3>Description: </h3>

        description= <p style={check}>{Data[0].description}</p>
    }
    if(comicsList.length==0)
    {
        comics=<h4>Comics: None</h4>  
    }
    else
    {
        comics=<h4>Comics: </h4>

        comicsList=<ul>{comicsList}</ul>
    }






return (
    <div>
    

    <h1><u>Character</u></h1>

    <br></br> <br></br>

    <h2>Name : {Data[0].name}</h2>

    <br></br> <br></br>

    {descHeading}
    

    {description}

    <br></br> <br></br>
    

    <img alt= {`${Data[0].name}`} src={`${Data[0].thumbnail.path}/portrait_xlarge.${Data[0].thumbnail.extension}`}></img>


    <br></br>  <br></br>  <br></br>

    {comics}

   {comicsList}
         
    
    </div>

)
}

else{

    return(<p>Loading...</p>)
}

}


export default CharacterPage