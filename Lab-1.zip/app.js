const express = require('express');
const app = express();

const session = require('express-session')

const configRoutes = require('./routes');
const blogData = require('./data/blog')


app.use(express.json());
app.use(express.urlencoded({ extended: true }));


app.use(session({
  name: 'AuthCookie',
  secret: 'some secret string!',
  resave: false,
  saveUninitialized: true
}))



 app.post('/blog',async (req, res, next) => {
  
  if(!req.session.user){
      res.status(403).json({user:"User is not logged in"});
  }else{
      next();
  }
});


app.patch('/blog/:id', async(req,res, next)=>{


  if(!req.session.user){
    res.status(403).json({user:"User is not logged in"});
    return
  }

  try{

        blogInfo=await blogData.getblog(req.params.id);
  
        
  
        if(blogInfo.userThatPosted._id == req.session.user._id)
        {
            next()
        }
        else{
          res.status(403).json({user:"User is not logged into correct account"});
          return;
        }

  }
    catch(e)
    {
      if(e=="Blog dosen't exist")
      {
        res.status(404).json({error:e})
      }
      else{
        res.status(400).json({error:e})
      }
    }
});  




 app.put('/blog/:id', async(req,res, next)=>{

  if(!req.session.user){
    res.status(403).json({user:"User is not logged in"});
  }

  try{

        blogInfo=await blogData.getblog(req.params.id);
  
       
  
        if(blogInfo.userThatPosted._id == req.session.user._id)
        {
            next()
        }
        else{
          res.status(403).json({user:"User is not logged into correct account"});
          return;
        }

  }
    catch(e)
    {
        

        res.status(404).json({error:e})
    }

});



app.post('/blog/:id/comments', async(req,res,next)=>{


  if(!req.session.user){
    res.status(403).json({user:"User is not logged in"});
}

else{
try{

  blogInfo=await blogData.getblog(req.params.id);

}
catch(e)
{
  res.status(404).json({error:e})
}

next()
}

}); 


app.delete('/blog/:blogId/:commentId', async(req,res,next)=>{


  if(!req.session.user){
    res.status(403).json({user:"User is not logged in"});
    return
}

try{

  commentData=await blogData.getComment(req.params.blogId, req.params.commentId);


  if(commentData.userThatPostedComment._id == req.session.user._id)
  {
      next()
  }
  else{
    res.status(403).json({user:"User is not logged into correct account"});
    return;
  }

}
catch(e)
{
  res.status(404).json({error:e})
}


});




app.get('/blog/logout', async(req,res,next)=>
{

    if(!req.session.user)
    {
      res.status(403).json({user:"User is not logged in"});
    }

    else{
      next()
    }

});


app.post('/blog/login', async(req,res,next)=>
{

    if(req.session.user)
    {
      res.status(403).json({user:"User is already logged in"});
    }

    else{
      next()
    }

});

app.post('/blog/signup', async(req,res,next)=>
{

    if(req.session.user)
    {
      res.status(403).json({user:"User is already logged in"});
    }

    else{
      next()
    }

});


configRoutes(app);

app.listen(3000, () => {
  console.log("We've now got a server!");
  console.log('Your routes will be running on http://localhost:3000');
});




