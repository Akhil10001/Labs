const express = require('express');
const { location } = require('express/lib/response');
const router = express.Router();
const data = require('../data');
const { createBlog } = require('../data/blog');
const blogData =data.blogs;
const usersData=data.users;



function getBlogCheck(queryString)
{

  if(Object.keys(queryString).length>2)
  {
    throw 'Please enter a valid queryString'
  }
  
  for(let x in queryString)
  {

      if(x!="skip" && x!="take")
      {
        throw 'Please use skip or take'
      }

      if(check_for_spaces(queryString[x]))
      {
            throw 'Please enter values for skip or take'
      }
      if(!isPositiveInteger(queryString[x]))
      {
        
        throw 'Please use only valid numbers for skip or take'
      }
         
      if(x=='take')
         {
      if(queryString[x]>100)
      {
        throw 'Please enter Integers below 101 and above zero'
      }
            }
  }
  
}


function blogCheck(title,body)
{

 if(!title || !body)
 {
   throw "Please enter title and body "
 } 

 else if(!isString(title) || !isString(body))
 {
    throw "title and body should be strings"
 }

 else if(check_for_spaces(title) || check_for_spaces(body))
 {
    throw "title and body should not be empty or only spaces"
 }

}

function patchCheck(title,body)
{


  if(!title && !body)
  {
    throw "Please enter title or body "
  } 
 
 if(typeof title!= 'undefined')
 {
    if(!isString(title))
    {
      throw "title should be string"
    }

    if(check_for_spaces(title))
    {
        throw "title should not be empty or only spaces"
    }
 }


 if(typeof body!= 'undefined')
 {
    if(!isString(body))
    {
      throw "body should be string"
    }

    if(check_for_spaces(body))
    {
        throw "body should not be empty or only spaces"
    }
 }

}



function isPositiveInteger(str) {
  if (typeof str !== 'string' ||  /^[-+]?[0-9]+\.[0-9]+$/.test(str)) {
    return false;
  }

  const num = Number(str);

  if (Number.isInteger(num) && num > 0) {
    return true;
  }

  return false;
}


function commentCheck(comment)
{

 if(!comment)
 {
   throw "Please enter comment "
 } 

 else if(!isString(comment))
 {
    throw "comment should be strings"
 }

 else if(check_for_spaces(comment))
 {
    throw "comment should not be empty or only spaces"
 }

}




function signUpCheck(name, username, password)
{

    if(!name)
    {
        throw 'Please enter name'
    }
    
    else if(!username)
    {
        throw 'Please enter username'
    }
    else if(!password)
    {
        throw 'please enter password'
    }

    else if(!isString(name) || !isString(username)|| !isString(password))
    {
        throw 'please enter only strings';
    }
    else if(check_for_spaces(name) || check_for_spaces(username)|| check_for_spaces(password))
    {
        throw "Enter data instead of spaces";
    }

    else if(name.trim()==0 || /^([a-zA-Z0-9]{4,})*$/.test(name)==false)
    {
        throw 'please check the name format'
    }

    else if(username.trim()==0 || /^([a-zA-Z0-9]{4,})*$/.test(username)==false)
    {
        throw 'please check the username format'
    }

    else if(/^([a-zA-Z0-9-!$%^&*()_+|~=`{}\[\]:\/;<>?,.@#]{6,})*$/.test(password)==false)
    {
        throw 'please check the password format'
    }


}



function paramCheck(username, password)
{

if(!username)
{
    throw 'Please enter username'
}
else if(!password)
{
    throw 'please enter password'
}
else if(username.trim()==0 || /^([a-zA-Z0-9]{4,})*$/.test(username)==false)
{
    throw 'please check the username format'
}
else if(/^([a-zA-Z0-9-!$%^&*()_+|~=`{}\[\]:\/;<>?,.@#]{6,})*$/.test(password)==false)
{
    throw 'please check the password format'
}


}



function check_id(id)
{
if(!id)
{
    throw "please enter id";
}
else if(typeof id!='string')
{
    throw "please enter id as string";
}
else if(check_for_spaces(id))
{
    throw "Enter id properly"
}
else if(!isValidObjectId(id))
{
    throw "Enter proper objectid as string"
}

}



function isValidObjectId(id){
  let { ObjectId } = require('mongodb');
  if(ObjectId.isValid(id)){
      if((String)(new ObjectId(id)) === id)
          return true;        
      return false;
  }
  return false;
}


function check_for_spaces(string)               //common code for strings
{
string=string.trim()
if(string.length>0)
{
  return false;
}
else
{
  return true;
}
}


function isString(x)                    //common code for strings
{
  return Object.prototype.toString.call(x) === "[object String]"
}



router.get('/', async (req, res) => {


    let queryString=req.query;

    try{

    if(Object.keys(queryString).length>0)
    {
        getBlogCheck(queryString)
    }
  }

   catch(e)
    {
      res.status(400).json({ error: e })
      return
    }


try{
    const blog = await blogData.getBlogPosts(queryString);
    res.status(200).json(blog);
}
catch (e) {
  res.status(500).send();
}
  

  }  );



router.post('/', async(req,res)=>
{


    const blogdata = req.body;

try{
    const {title,body} = blogdata;

    blogCheck(title,body);

    const newBlog= await blogData.createBlog(title,body,req.session.user);
       
    res.status(200).json(newBlog)
}

  catch(e)
  {
    res.status(400).json({ error: e });
  }


});



router.put('/:id', async(req,res)=>
{

  const blogdata =req.body
  const {title, body}= blogdata;
  

  try{
        
        blogCheck(title,body);
        check_id(req.params.id)

  }

  catch(e)
  {
      res.status(400).json({error:e})
      return;
  }




  try{

    
    const putBlog= await blogData.putBlog(req.params.id,title,body);
    res.status(200).json(putBlog)

  }
  catch(e)
  {
    res.status(404).json({error:e})
  }
})




router.patch('/:id', async(req,res)=>{

  const blogdata =req.body

  const {title, body}= blogdata;
  
  let updateBlog={}

  try{
        
        patchCheck(title,body);
        check_id(req.params.id)

  }

  catch(e)
  {
      res.status(400).json({error:e})
      return;
  }


  if('title' in blogdata)
  {
    updateBlog.title=blogdata.title
  }

  if('body' in blogdata)
  {
    updateBlog.body=blogdata.body
  }

try{
  const patchBlog= await blogData.patchBlog(req.params.id,updateBlog);

  res.status(200).json(patchBlog)
}

catch(e)
{

  res.status(404).json({error:e})
}


})




router.post('/:id/comments', async(req,res)=>{

  const blogdata =req.body

  const {comment}= blogdata;

  try{

    check_id(req.params.id)
    commentCheck(comment)

  }

  catch(e)
  {
    res.status(400).json({error:e})
    return;
  }

  try{

    const addComment=await blogData.addComment(req.params.id,comment, req.session.user)

    res.status(200).json(addComment)
  }

  catch(e)
  {
    res.status(404).json({error:e})
  }

})




router.delete('/:blogId/:commentId', async(req,res)=>{


  try{

       check_id(req.params.blogId)
        check_id(req.params.commentId)

    }

    catch(e)
      {
        res.status(400).json({error:e})
    }

    try{

        const deleteComment=await blogData.deleteComment(req.params.blogId,req.params.commentId)
        res.status(200).json(deleteComment)
    }

    catch(e)
    {
      res.status(404).json({error:e})   
    }

})


router.post('/signup', async(req,res)=>{

  let name=req.body.name
  let userName=req.body.username;
  let password=req.body.password;

  try{

      signUpCheck(name,userName,password)

      const signUp= await usersData.signUp(req.body.name,req.body.username,req.body.password)

      res.status(200).json(signUp)
  }
  catch(e)
  {
    res.status(400).json({error:e}) 

  }



})


router.post('/login', async(req,res)=>{


  let userName=req.body.username;
  let password=req.body.password;

  try{

    paramCheck(userName,password)

    const login= await usersData.login(req.body.username,req.body.password)

    req.session.user={username : login.username, _id : login._id}
  
    res.status(200).json(login)

  }
  catch(e)
  {
    res.status(400).json({error:e}) 

  }

  

})


router.get('/logout',async(req,res)=>{

  if(req.session.user)
  {
  req.session.destroy()
  
  res.clearCookie('AuthCookie')

  res.status(200).json({user: "logged out"})
  }



  })



  router.get('/:id', async(req,res)=>
{


  try{
    check_id(req.params.id)
  }
  catch(e)
  {
    res.status(400).json({ error: e });
    return;
  }

  try {
   
    
    const blog= await blogData.getblog(req.params.id)

    res.status(200).json(blog)
  
} 

catch (e) {
    res.status(404).json({error: e})
}


});


module.exports = router;