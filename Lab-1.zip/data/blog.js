const mongoCollections = require('../config/mongoCollections');
const blogs = mongoCollections.blogs;




function getBlogCheck(queryString)
{

  if(Object.keys(queryString).length>2)
  {
    throw 'Please enter a valid queryString'
  }
  
  for(let x in queryString)
  {

      if(x!="skip" && x!="take")
      {
        throw 'Please use skip or take'
      }

      if(check_for_spaces(queryString[x]))
      {
            throw 'Please enter values for skip or take'
      }

      if(!isPositiveInteger(queryString[x]))
      {
        
        throw 'Please use only valid numbers for skip or take'
      }

         if(x=='take')
         {
      if(queryString[x]>100)
      {
        throw 'Please enter Integers below 101 and above zero'
      }
            }
  }
  
}



function blogCheck(title,body)
{

 if(!title || !body)
 {
   throw "Please enter title and body "
 } 

 else if(!isString(title) || !isString(body))
 {
    throw "title and body should be strings"
 }

 else if(check_for_spaces(title) || check_for_spaces(body))
 {
    throw "title and body should not be empty or only spaces"
 }

}


function patchCheck(title,body)
{


  if(!title && !body)
  {
    throw "Please enter title or body "
  } 
 
 if(typeof title!= 'undefined')
 {
    if(!isString(title))
    {
      throw "title should be string"
    }

    if(check_for_spaces(title))
    {
        throw "title should not be empty or only spaces"
    }
 }


 if(typeof body!= 'undefined')
 {
    if(!isString(body))
    {
      throw "body should be string"
    }

    if(check_for_spaces(body))
    {
        throw "body should not be empty or only spaces"
    }
 }

}


function isPositiveInteger(str) {
    if (typeof str !== 'string' ||  /^[-+]?[0-9]+\.[0-9]+$/.test(str)) {
      return false;
    }
  
    const num = Number(str);
  
    if (Number.isInteger(num) && num > 0) {
      return true;
    }
  
    return false;
  }


function check_id(id)
{
if(!id)
{
    throw "please enter id";
}
else if(typeof id!='string')
{
    throw "please enter id as string";
}
else if(check_for_spaces(id))
{
    throw "Enter id properly"
}
else if(!isValidObjectId(id))
{
    throw "Enter proper objectid as string"
}

}


function commentCheck(comment)
{

 if(!comment)
 {
   throw "Please enter comment "
 } 

 else if(!isString(comment))
 {
    throw "comment should be strings"
 }

 else if(check_for_spaces(comment))
 {
    throw "comment should not be empty or only spaces"
 }

}


function isValidObjectId(id){
    let { ObjectId } = require('mongodb');
    if(ObjectId.isValid(id)){
        if((String)(new ObjectId(id)) === id)
            return true;        
        return false;
    }
    return false;
  }


function check_for_spaces(string)               //common code for strings
{
string=string.trim()
if(string.length>0)
{
  return false;
}
else
{
  return true;
}
}


function isString(x)                    //common code for strings
{
  return Object.prototype.toString.call(x) === "[object String]"
}

module.exports={


async getblogsbyid(id)
{

    const res=await blogs();
const blog=await res.findOne({_id:id});
return blog;
},


async getblog(id)
{
    check_id(id)

    let {ObjectId}=require('mongodb');

    let parsedId=ObjectId(id);

    let object=await this.getblogsbyid(parsedId);

    if(object==null)
    {
        throw "Blog dosen't exist"
    }

    object._id=object._id.toString()

    for(let i=0;i<object.comments.length;i++)
{
    object.comments[i]._id=object.comments[i]._id.toString()
}

    return object

},


async getBlogPosts(queryObject)
{

    if(Object.keys(queryObject).length>0)
    {
        getBlogCheck(queryObject)
    }


    let blogList
    const blogCollection = await blogs();


    if(Object.keys(queryObject).length>0)
    {
        if(queryObject.skip && !queryObject.take)
        {
            blogList = await blogCollection.find({}).skip(parseInt(queryObject.skip)).toArray();
        }

        else if(!queryObject.skip && queryObject.take)
        {
            blogList = await blogCollection.find({}).limit(parseInt(queryObject.take)).toArray();
        }

        else if(queryObject.skip && queryObject.take)
        {
            blogList = await blogCollection.find({}).skip(parseInt(queryObject.skip)).limit(parseInt(queryObject.take)).toArray();

        }

    }

    else
    {
        blogList = await blogCollection.find({}).limit(20).toArray();
    }


    for(let i=0;i<blogList.length;i++)
    {
        blogList[i]._id=blogList[i]._id.toString()

        for(let j=0;j<blogList[i].comments.length;j++)
        {
            blogList[i].comments[j]._id=blogList[i].comments[j]._id.toString()
        }
    }
    
    return blogList;

},

async createBlog(title,body,user)
{

    blogCheck(title,body);

    title=title.trim()
    body=body.trim()

    let userid=user._id;
    let currentUser;

    let {ObjectId}=require('mongodb');
    let parsedId= ObjectId(userid);
    
    currentUser={
        _id: parsedId,
        username: user.username
    }

    let newblogData=
    {

        title:title,
        body:body,
        userThatPosted:currentUser,
        comments:[]

    }

    const blogCollection= await blogs();

    const insertInfo= await blogCollection.insertOne(newblogData);



    const blog= insertInfo.insertedId;

    const blogobject=await this.getblogsbyid(blog);

    blogobject._id= blogobject._id.toString();

    return blogobject;


},


async putBlog(id, title, body)
{

    blogCheck(title,body);

    check_id(id)

    let {ObjectId}=require('mongodb');
    let parsedId= ObjectId(id);

    const blog= await blogs()

    let object=await this.getblogsbyid(parsedId);

        if(object==null)
        {
           throw "Blog dosen't exist"
        }


    let obj=await blog.updateOne({_id:parsedId},{ $set: {
    
                                    title:title,
                                    body: body
                                }});

    let updatedBlog=await  this.getblogsbyid(parsedId);


    updatedBlog._id=updatedBlog._id.toString()

    for(let i=0;i<updatedBlog.comments.length;i++)
        {
            updatedBlog.comments[i]._id = updatedBlog.comments[i]._id.toString()
        }
    

    return updatedBlog;


},


async patchBlog(id,updateBlog)
{

    let titleCheck,bodyCheck

   

    if('title' in updateBlog)
    {
        titleCheck=updateBlog.title
    }

    if('body' in updateBlog)
    {
        bodyCheck=updateBlog.body
    }


    patchCheck(titleCheck,bodyCheck);

    check_id(id)


    let title,body

    let {ObjectId}=require('mongodb');

    let parsedId= ObjectId(id);

    let object=await this.getblogsbyid(parsedId);

        if(object==null)
        {
           throw "Blog dosen't exist"
        }


    let blog= await blogs()

    let oldBlog= await this.getblogsbyid(parsedId)

    if(updateBlog.title && updateBlog.title!=oldBlog.title)
    {
        title=updateBlog.title;
        
    }
    else if(updateBlog.title && updateBlog.title==oldBlog.title)
    {
        throw "Please change title to something new"
    }
    else
    {
        title=oldBlog.title;
    }

    if(updateBlog.body && updateBlog.body!=oldBlog.body)
    {
        body=updateBlog.body;
    }

    else if(updateBlog.body && updateBlog.body==oldBlog.body)
    {
        throw "Please change body to something new"
    }

    else
    {
        body=oldBlog.body;
    }

    let obj=await blog.updateOne({_id:parsedId},{ $set: {
    
    title:title,
    body: body
    }});


    let updatedBlog=await  this.getblogsbyid(parsedId);

    updatedBlog._id=updatedBlog._id.toString()

    for(let i=0;i<updatedBlog.comments.length;i++)
        {
            updatedBlog.comments[i]._id = updatedBlog.comments[i]._id.toString()
        }

    return updatedBlog;
},






async addComment(id,comment,userThatPostedComment)
{

    check_id(id)

    commentCheck(comment)

    let currentUser;

    let {ObjectId}=require('mongodb');

    let parsedId= ObjectId(id);

    let object=await this.getblogsbyid(parsedId);

        if(object==null)
        {
           throw "Blog dosen't exist"
        }

    let userId= ObjectId(userThatPostedComment._id);

    currentUser={

        _id: userId,
        username: userThatPostedComment.username
    }


    let blog= await blogs()

    let newObjId = ObjectId();

    


    let obj=await blog.updateOne({_id:parsedId},{ $push:{ comments:{_id:newObjId,
        
        comment:comment,
        userThatPostedComment:currentUser
    
    }}})

    let blogContent= await this.getblogsbyid(parsedId)

    blogContent._id=blogContent._id.toString()

    for(let i=0;i<blogContent.comments.length;i++)
        {
            blogContent.comments[i]._id = blogContent.comments[i]._id.toString()
        }

    return blogContent


},



async deleteComment(blogId,commentId)
{

    check_id(blogId)

    check_id(commentId)

    let commentExist=false;

    let {ObjectId}=require('mongodb');

    let blog_id= ObjectId(blogId);

    let comment_id=ObjectId(commentId)

    let object=await this.getblogsbyid(blog_id);

        if(object==null)
        {
           throw "Blog dosen't exist"
        }

        else{

                for(let i=0; i<object.comments.length;i++)
                {
                    if(object.comments[i]._id == commentId)
                    {
                            commentExist=true;
                    }
                }
        }

        if(commentExist==false)
        {
            throw "Comment dosen't exist in this blog"
        }


    let blog= await blogs()

   let obj= await blog.updateOne({_id:blog_id},{$pull: {comments:{ "_id": comment_id}}})

    let blogdata=await this.getblogsbyid(blog_id)



    blogdata._id=blogdata._id.toString()

    for(let i=0;i<blogdata.comments.length;i++)
        {
            blogdata.comments[i]._id = blogdata.comments[i]._id.toString()
        }



    return blogdata



},


async getComment(blogId,commentId)
{

    check_id(blogId)

    check_id(commentId)

    let commentExist=false;

    let {ObjectId}=require('mongodb');

    let blog_id= ObjectId(blogId);

    let commentInfo

    let object=await this.getblogsbyid(blog_id);

        if(object==null)
        {
           throw "Blog dosen't exist"
        }

        else{

                for(let i=0; i<object.comments.length;i++)
                {
                    if(object.comments[i]._id == commentId)
                    {
                            commentExist=true;
                            commentInfo=object.comments[i]
                            commentInfo.userThatPostedComment._id=commentInfo.userThatPostedComment._id.toString()
                    }
                }
        }

        if(commentExist==false)
        {
            throw "Comment dosen't exist in this blog"
        }


    return commentInfo


        
}



};