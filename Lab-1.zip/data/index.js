const blogsData = require('./blog');
const usersData = require('./users')


module.exports = {
  blogs:blogsData,
  users:usersData
  
};