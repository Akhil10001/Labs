const mongoCollections = require('../config/mongoCollections');
const users = mongoCollections.users;
const bcrypt = require('bcryptjs');
const saltRounds = 16;




function signUpCheck(name, username, password)
{

    if(!name)
    {
        throw 'Please enter name'
    }
    
    else if(!username)
    {
        throw 'Please enter username'
    }
    else if(!password)
    {
        throw 'please enter password'
    }

    else if(!isString(name) || !isString(username)|| !isString(password))
    {
        throw 'please enter only strings';
    }
    else if(check_for_spaces(name) || check_for_spaces(username)|| check_for_spaces(password))
    {
        throw "Enter data instead of spaces";
    }

    else if(name.trim()==0 || /^([a-zA-Z0-9]{4,})*$/.test(name)==false)
    {
        throw 'please check the name format'
    }

    else if(username.trim()==0 || /^([a-zA-Z0-9]{4,})*$/.test(username)==false)
    {
        throw 'please check the username format'
    }

    else if(/^([a-zA-Z0-9-!$%^&*()_+|~=`{}\[\]:\/;<>?,.@#]{6,})*$/.test(password)==false)
    {
        throw 'please check the password format'
    }


}



function paramCheck(username, password)
{

if(!username)
{
    throw 'Please enter username'
}
else if(!password)
{
    throw 'please enter password'
}
else if(username.trim()==0 || /^([a-zA-Z0-9]{4,})*$/.test(username)==false)
{
    throw 'please check the username format'
}
else if(/^([a-zA-Z0-9-!$%^&*()_+|~=`{}\[\]:\/;<>?,.@#]{6,})*$/.test(password)==false)
{
    throw 'please check the password format'
}


}





function check_for_spaces(string)               //common code for strings
{
string=string.trim()
if(string.length>0)
{
  return false;
}
else
{
  return true;
}
}


function isString(x)                    //common code for strings
{
  return Object.prototype.toString.call(x) === "[object String]"
}




module.exports={



    async getUser(id)
    {
        const userData=await users();
        const user=await userData.findOne({_id:id});
        return user;


    },


    



    async findUser(username)
{
    const userCollection=await users()
   
    const userCollectionArray=await userCollection.find({}).toArray()

    for(let i=0;i<userCollectionArray.length;i++)
    {
        if(username.toLowerCase()==userCollectionArray[i].username.toLowerCase())
        {
            return userCollectionArray[i];
        }
    }

    return null;

},


    async signUp(name, username, password)
    {

        signUpCheck(name, username, password)

        const userinfo= await this.findUser(username)
        if(userinfo!=null)
        {
            throw 'username already exists'
        }


        
        const hash = await bcrypt.hash(password, saltRounds); 


        let userdata={

            name:name,
            username:username,
            password:hash

        }

        let userCollection=await users()

        let userData=await userCollection.insertOne(userdata)

        let user_id= userData.insertedId

        let user= await this.getUser(user_id)

        user._id= user._id.toString()

        return user
    },




    async login(username,password)
    {

        paramCheck(username,password)

        const userinfo= await this.findUser(username)
    
        if(userinfo==null)
        {
            throw 'Either the username or password is invalid' 
        }
        

        storedPassword= userinfo.password

        let compare = await bcrypt.compare(password, storedPassword);


        if(compare)
        {
            userinfo._id=userinfo._id.toString()
            
            return userinfo
        }

        else{
            throw 'Either the username or password is invalid'
        }

    }










}