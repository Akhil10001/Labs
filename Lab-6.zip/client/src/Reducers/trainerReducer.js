import {v4 as uuid} from 'uuid';

const initalState = [
  {
    id: uuid(),
    name: 'Ash Ketchum',
    selected: true,
    team:[]
  }
];

let copyState = null;
let index = 0;
let alreadySelected,selected

const trainerReducer = (state = initalState, action) => {
  const {type, payload} = action;

  switch (type) {

    case 'CREATE_TRAINER':
      console.log('payload', payload);
      return [...state, {id: uuid(), name: payload.name, selected:false, team:[]}];

      case 'SELECT_TRAINER':
        copyState = [...state];
      selected = copyState.find((x) => x.id === payload.id);
      alreadySelected = copyState.find((x) => x.selected === true);
      alreadySelected.selected=false
      selected.selected=true
      return [...state];

    case 'DELETE_TRAINER':
      copyState = [...state];
      index = copyState.findIndex((x) => x.id === payload.id);
      copyState.splice(index, 1);
      return [...copyState];


      case 'ADD_POKEMON':
        copyState = [...state];
        selected = copyState.find((x) => x.selected === true);
        selected.team.push(payload.pokemon)
        return[...copyState]

        case 'DELETE_POKEMON':
      copyState = [...state];
      selected= copyState.findIndex((x) => x.selected === true);
      index = copyState[selected].team.findIndex((x) => x === payload.pokemon);
      copyState[selected].team.splice(index, 1);
      return [...copyState];

    default:
      return state;
      
  }
};

export default trainerReducer;
