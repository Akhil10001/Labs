

import { Link,useParams } from 'react-router-dom';
import axios from 'axios';
import {useSelector} from 'react-redux';
import {Button,Image,Container,Row, Col} from 'react-bootstrap'
import CatchRelease from './CatchRelease'
import fallBackSrc from '../Assets/NoImage_450x450.jpg' 
import Card from "react-bootstrap/Card";
const { useEffect, useState } = require('react');



const PokemonsPage=()=>{


    let allTrainers = useSelector((state) => state.trainers);
    let trainer= allTrainers.find((x)=>x.selected==true) 
  
      let { pagenum } = useParams()
  
      const[Data, setData]=useState(undefined)

      const [checkPage, setcheckPage]= useState(false)
    
      
      const [ nextTerm,   setNextTerm ]  = useState(true)
      const [ previousTerm,  setPreviousTerm ]  = useState(true)

      const [searchTerm,setSearchTerm]= useState('')
      const [searchData,setSearchData]= useState()

        
  
      let listItems,searchItem
  
    
  
      useEffect(()=>{
  
          async function fetchData()
          {

            try{

                if( isNaN(pagenum) || parseInt(pagenum)<0)
                {
            
                   setcheckPage(true)
                 
                }
                else
                {

              const {data} = await axios.get('http://localhost:4000/pokemon/page/'+pagenum)
  
           
                    setcheckPage(false)
                
              setData(data.data.results)
  
              if(data.data.next==null)
              {
                  setNextTerm(false)
                  setPreviousTerm(true)
              }

             else if(data.data.previous==null)
             {
                 setNextTerm(true)
                setPreviousTerm(false)
             }
             else
                {
                    setNextTerm(true)
                    setPreviousTerm(true) 
                }


            }


            }

            catch(e)
            {
              setcheckPage(true)
            }

          } 
       
          fetchData()
       },[pagenum])


const handleClick=async()=>{

    try{
    const {data} = await axios.get(`http://localhost:4000/pokemon/search/${searchTerm.trim()}`);

    setcheckPage(false)

    setSearchData(data.data)

    }

    catch(e)
    {
        setcheckPage(true)
    }



}


const changeState=()=>{

setSearchData(undefined)

setSearchTerm(()=>'')

}


const handleError=()=>{

    setSearchData(undefined)

setSearchTerm(()=>'')

    setcheckPage(false)
}




if(Data==undefined && checkPage==false){



        return(<p>Loading....</p>)
    }
  
    else if(checkPage)
    {
    
       
        return(<div><h1>PageNotFound: 404</h1>

        <br/> <br/>
        
        {Data!=undefined?<Button onClick={()=>handleError()}>Back to all data</Button>:null}

        {Data==undefined?<Button> Click Pokemons for data</Button>:null}

        </div>

        )
    }
    else if(searchData!=undefined)
     {

       searchItem= <Col md={3} key={searchData.id}>
          <Card key={searchData.id} style={{ width: "19rem" }} className={"mb-4"}>

              <Card.Body>
          <Card.Title><p>{searchData.name}</p></Card.Title>
          <Link  aria-label={"More info when clicked"}  to={`/pokemon/${searchData.id}`}>  
          <Image className="card-img-top" alt={searchData.id} src={`https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${searchData.id}.png`}/>
              </Link>
              <CatchRelease pokemon={`${searchData.id}`} trainer={trainer}/> 
          </Card.Body>
          </Card>
          </Col>    
          
     }
      else if(Data.length>0)
     {


          listItems=Data.map((pokemons,index)=>

          <Col md={3} key={index}>
          <Card key={index} style={{ width: "19rem" }} className={"mb-4"}>

              <Card.Body>
          <Card.Title><p>{pokemons.name}</p></Card.Title>
          <Link  aria-label={"More info when clicked"}  to={`/pokemon/${pokemons.url.split('/')[6]}`}>  
          <Image className="card-img-top" alt={index} src={`https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${pokemons.url.split('/')[6]}.png`}
          
          onError={(e)=>(e.currentTarget.src = fallBackSrc)}

          />
              </Link>
              <CatchRelease pokemon={`${pokemons.url.split('/')[6]}`} trainer={trainer}/> 
          </Card.Body>
          </Card>
          </Col>       
         

         )
     }
   
    

     


return(

<div >
    <br></br>
<div>
<label>
    

<input


type="text"

onChange={(e)=>setSearchTerm(e.target.value)}
value={searchTerm}

/>
</label>

&nbsp;&nbsp;&nbsp;
<button onClick={()=>{
    
    if(searchTerm.trim()=='')
    {
        alert('Please enter search term')
    }
    else if(/\d/.test(searchTerm.trim()))
    {
        alert('Please enter name in the search term')
    }
    else
    {

    handleClick()
}}

}>Search</button>
&nbsp;&nbsp;&nbsp;
{searchData?<button onClick={()=>changeState()}>Back to all data</button>:null}

</div>




<br/> <br/>
<Container>
          <Row md={4}>
            
             {listItems}
            
          </Row>
      </Container>  

      <br/> <br/>
<Container>
          <Row md={4}>
            
             {searchItem}
            
          </Row>
      </Container>  

      <br></br>
      <br></br>
      <br></br>
				{
                   
				((Data.length>0) && nextTerm && searchData==undefined)?<Button as={Link} to={`/pokemon/page/${parseInt(pagenum)+1}`}>
					Next
				</Button>:null
				}
				&nbsp;&nbsp;&nbsp;
				{
				((Data.length>0)&&previousTerm && searchData==undefined)?<Button as={Link} to={`/pokemon/page/${parseInt(pagenum)-1}`}>
					Previous
				</Button>:null
				}
</div>
)

}



export default PokemonsPage