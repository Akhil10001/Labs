import {useParams } from 'react-router-dom';
import axios from 'axios';
import {useSelector} from 'react-redux';
import CatchRelease from './CatchRelease'
import {Button,Image} from 'react-bootstrap'
import fallBackSrc from '../Assets/NoImage_450x450.jpg'
const { useEffect, useState } = require('react');








const PokemonPage=()=>{

    
    let allTrainers = useSelector((state) => state.trainers);
  let trainer= allTrainers.find((x)=>x.selected==true) 

    let { id } = useParams()

    const[Data, setData]=useState(undefined)
    const [checkPage, setcheckPage]= useState(false)

    let listItems




    useEffect(()=>{

        async function fetchData()
        {

        
          if( isNaN(id) || parseInt(id)<0)
          {
      
             setcheckPage(true)
          }
          else
          {

            try{
            const {data} = await axios.get('http://localhost:4000/pokemon/'+id)

            setcheckPage(false)

            setData(data.data)

            }

            catch(e)
            {
              setcheckPage(true)
            }
          }
           


        } 
     
        fetchData()
     },[id])
     


     if(checkPage)
{
    return(<div><h1>PageNotFound: 404</h1></div>)
}


else if(Data==undefined ){


        return(<p>Loading....</p>)
    }
      if(Data!=undefined)
     {


          listItems=Data.types.map((pokemon,index)=>


         <li key={index}>  
           
           <p style={ {fontSize: 18}}>{pokemon.type.name}</p>
             
         </li>)
     }







return(

<div>

    <h1>{Data.name}</h1>
    <br/><br/>

    <Image alt={Data.name} src={`https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${id}.png`} 
    
    onError={(e)=>(e.currentTarget.src = fallBackSrc)}></Image>

    <br/><br/>
<h2>Types</h2>
<ol>{listItems}</ol>

<CatchRelease pokemon={id} trainer={trainer}/> 

</div>

)



}


export default PokemonPage

