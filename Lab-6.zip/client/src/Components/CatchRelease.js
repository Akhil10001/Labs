import {Button} from 'react-bootstrap'
import actions from '../Actions/actions';
import {useDispatch} from 'react-redux';

const CatchRelease=(props)=>{



  
  

  let pokemon
  let button,bool=true
  
if(props.trainer)
{
  if(props.trainer.team)
  {
      if(props.trainer.team.length==6)
      {
          bool=false
          pokemon=props.trainer.team.find((x)=>x==props.pokemon)  
      }

    else if(props.trainer.team.length>0)
    {
    
      bool=true
  pokemon=props.trainer.team.find((x)=>x==props.pokemon)  
    }
  }

}

  const dispatch = useDispatch();

 

const setButton=()=>{
  
  if(button=="Catch")
{
    dispatch(actions.addPokemon(props.pokemon))
}
else if(button=="Release")
{
  dispatch(actions.deletePokemon(props.pokemon)) 
}

}


if(bool)
{
 button= (pokemon!=null)?"Release":"Catch"
}

else{

  button= (pokemon!=null)?"Release":"Full"

}



  return(

    <div>

      <Button onClick={setButton}>{button}</Button>


    </div>

  )




}

export default CatchRelease