

const Home= ()=>{



return(

  <div>
        
  <div className="intro" style={{display: 'flex',  justifyContent:'center', alignItems:'center', height: '50vh'}}>
    <br></br>
      <p>Trainers can catch and release Pokémon for the battle to come...!</p>
  </div>
</div>

          
        )


        


}

export default Home