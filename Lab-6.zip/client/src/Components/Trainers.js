import {useState} from 'react';
import { Button } from 'react-bootstrap';
import {useSelector} from 'react-redux';
import AddTrainer from './AddTrainer';
import Trainer from './Trainer';


 const Trainers=()=> {


  const [addBtnToggle, setBtnToggle] = useState(false);
  const allTrainers = useSelector((state) => state.trainers);
 
  return (
    <div className='todo-wrapper' >
      <br></br>
      <br></br>
      <br></br>
      <Button onClick={() => setBtnToggle(!addBtnToggle)}>Add A Trainer</Button>
      <br />
      <br />
      <br />
      {addBtnToggle && <AddTrainer />}
      <br />
      {allTrainers.map((trainer) => {
        return <Trainer key={trainer.id} trainer={trainer} />;
      })}
    </div>
  );
}

export default Trainers;
