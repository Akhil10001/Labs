import {useState} from 'react';
import {useDispatch} from 'react-redux';
import actions from '../Actions/actions';
import {Button} from 'react-bootstrap'

const AddTrainer=()=> {

  const dispatch = useDispatch();
  const [formData, setFormData] = useState({task: '', taskDesc: ''});

  const handleChange = (e) => {
    setFormData((prev) => ({...prev, [e.target.name]: e.target.value}));
  };
  const addTrainer = () => {

    let name=document.getElementById('name').value

    if(name=='')
    {
      alert('Please enter Trainer name')
    }
    else if(!isNaN(name))
    {
      alert('Please enter Trainer name as string')
    }
    else
    {

    dispatch(actions.addTrainer(formData.name));

    document.getElementById('name').value = '';

    }
  };
  console.log(formData);
  return (
    <div className='add'>
      <div className='input-selection'>
        <label>
          <input
            onChange={(e) => handleChange(e)}
            id='name'
            name='name'
            placeholder='Name...'
          />
        </label>
        
      </div>
      <br></br>
      <Button onClick={addTrainer}>Add Trainer</Button>
      <br></br>
      <br></br>
    </div>
  );
}

export default AddTrainer;
