import {useDispatch} from 'react-redux';
import actions from '../Actions/actions';
import {Button,Image,Container,Row,Card,Col} from 'react-bootstrap'
import { Link } from 'react-router-dom';
import fallBackSrc from '../Assets/NoImage_450x450.jpg'



const Trainer=(props)=> {
  
  const dispatch = useDispatch();

  const deleteTrainer = () => {
    dispatch(actions.deleteTrainer(props.trainer.id));
  };

  const selectedTrainer=()=>{

    dispatch(actions.selectTrainer(props.trainer.id));    

  }

 
  
  let items=props.trainer.team.map((pokemon,index)=>{

return(
    
            <Col key={index}>
          <Card key={index} style={{ width: "12rem" }} className={"mb-4"} >


              <Card.Body>
          <Link  aria-label={"More info when clicked"}  to={`/pokemon/${pokemon}`}>  
          <Image className="card-img-top" alt={index} src={`https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${pokemon}.png`}
          
          onError={(e)=>(e.currentTarget.src = fallBackSrc)}
          />
              </Link>
          </Card.Body>
          </Card>
          </Col>       
         
      )

      })

  return (
    <div className='todo-wrapper'>
      
          {(props.trainer.selected==true)?<p style={ {fontSize: 35}}><u>Selected</u></p>:null}

<br></br>
           <p style={ {fontSize: 35}}>Trainer: {props.trainer.name}</p>

           <br></br>
              
          
              {(props.trainer.selected==false)?<Button onClick={selectedTrainer}>Select Trainer</Button>:null}

              &nbsp;&nbsp;&nbsp;
            
              {(props.trainer.selected==false)?<Button onClick={deleteTrainer}>Delete Trainer</Button>:null}

              <br></br>
              <br></br>

              <Container>
          <Row>
            
             {items}
            
          </Row>
      </Container>  

      <br></br>
      <br></br>
             
    </div>
  );
}

export default Trainer;
