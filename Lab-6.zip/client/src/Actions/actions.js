
  const addTrainer = (name) => ({
    type: 'CREATE_TRAINER',
    payload: {
      name: name,
    }
  });
  
  const deleteTrainer = (id) => ({
    type: 'DELETE_TRAINER',
    payload: {id: id}
  });


  const selectTrainer = (id) => ({
    type: 'SELECT_TRAINER',
    payload: {id: id}
  });


  const addPokemon= (pokemon)=>({

    type: 'ADD_POKEMON',
    payload:{pokemon:pokemon}

  })

  const deletePokemon = (pokemon)=>({

    type: 'DELETE_POKEMON',
    payload:{pokemon:pokemon}

  })
  
  module.exports = {
    
    addTrainer,
    deleteTrainer,
    selectTrainer,
    addPokemon,
    deletePokemon
  };
  