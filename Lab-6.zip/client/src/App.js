import { BrowserRouter as Router, Route, Link, Routes } from 'react-router-dom';
import './App.css';
import Home from './Components/Home'
import Trainers from './Components/Trainers'
import PokemonsPage from './Components/PokemonsPage'
import PokemonPage from './Components/PokemonPage'
import ErrorPage from './Components/ErrorPage'
import {Nav,Navbar,Container} from 'react-bootstrap'



function App() {
  return (
    <Router>



<div className='App'>


   {/*  <Link className="showlink" to="/">Home</Link>
    &nbsp;&nbsp;
    <Link className="showlink" to="/trainers">Trainers</Link>
    &nbsp;&nbsp;
    <Link className="showlink" to="/pokemon/page/0">Pokemons</Link> */}


    <Navbar bg="dark" variant="dark">
    <Container>
    <Navbar.Brand as={Link} to="/">Home</Navbar.Brand>
    <Nav className="me-auto">

      <Nav.Link as={Link}  to="/trainers">Trainers</Nav.Link>
      <Nav.Link as={Link} to="/pokemon/page/0">Pokemons</Nav.Link>
    </Nav>
    </Container>
  </Navbar>

          </div>

	   <div className='App-body' style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}>
    <Routes>
    <Route path="/" element={<Home />}></Route>
	  <Route path="/trainers" element={<Trainers />}></Route>
    <Route path="/pokemon/page/:pagenum" element={<PokemonsPage />}></Route>
    <Route path="/pokemon/:id" element={<PokemonPage />}></Route>
    <Route path="*" element={<ErrorPage />}></Route>
    
    </Routes>
	</div>
  </Router>
  );
}

export default App;
