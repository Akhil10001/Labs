import "./App.css";

import {
  NavLink,
  BrowserRouter as Router,
  Route,
  Routes,
} from "react-router-dom";

import Home from "./Components/Home";
import Bin from "./Components/Bin";
import MyPost from "./Components/MyPost";
import NewPost from "./Components/NewPost";
import ErrorPage from "./Components/ErrorPage";
import Popularity from "./Components/Popularity";

import {
  ApolloClient,
  HttpLink,
  InMemoryCache,
  ApolloProvider,
} from "@apollo/client";
const client = new ApolloClient({
  cache: new InMemoryCache(),
  link: new HttpLink({
    uri: "http://localhost:4000",
  }),
});

function App() {
  return (
    <ApolloProvider client={client}>
      <Router>
        <div className="App">
          <header>
            <h1 className="App-title text-center">Binterest</h1>
            <nav>
              <NavLink className="navlink navbar-brand" to="/">
                Home
              </NavLink>
              &nbsp;&nbsp;
              <NavLink className="navlink navbar-brand" to="/my-bin">
                My Bin
              </NavLink>
              &nbsp;&nbsp;
              <NavLink className="navlink navbar-brand" to="/my-posts">
                My Posts
              </NavLink>
              &nbsp;&nbsp;
              <NavLink className="navlink navbar-brand" to="/popularity">
                Popularity
              </NavLink>
            </nav>
          </header>
        </div>

        <div
          className="App-body"
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <Routes>
            <Route exact path="/" element={<Home />} />
            <Route path="/my-bin" element={<Bin />} />
            <Route path="/my-posts" element={<MyPost />} />
            <Route path="/new-post" element={<NewPost />} />
            <Route path="/popularity" element={<Popularity />} />
            <Route path="*" element={<ErrorPage />} />
          </Routes>
        </div>
      </Router>
    </ApolloProvider>
  );
}

export default App;
