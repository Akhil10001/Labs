import { useQuery, useMutation } from "@apollo/client";
import { DELETE_IMAGE, USER_POSTED_IMAGE, BINNED_IMAGES } from "../queries";
import Image from "../Components/Image";
import { Card, Button } from "react-bootstrap";
import "bootstrap/dist/css/bootstrap.min.css";
import { Link } from "react-router-dom";

const MyPost = () => {
  let body;

  const [removeImage] = useMutation(DELETE_IMAGE, {
    refetchQueries: [{ query: USER_POSTED_IMAGE }, { query: BINNED_IMAGES }],
  });

  const { loading, data, error } = useQuery(USER_POSTED_IMAGE);

  if (loading) {
    return <p>Loading....</p>;
  }

  if (error) {
    return <p>Something went wrong...!</p>;
  }

  if (data) {
    if (data.userPostedImages) {
      body = data.userPostedImages.map((image) => {
        return (
          <ol key={image.id}>
            <Card style={{ width: "20rem" }}>
              <Card.Img alt={image.id} src={image.url} />
              <Card.Body>
                <Card.Title>poster name: {image.posterName}</Card.Title>
                <Card.Text>{image.description}</Card.Text>
                <Image image={image} />
                <br></br>
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    removeImage({
                      variables: { id: image.id },
                    });
                    alert("removed");
                  }}
                >
                  <button className="btn btn-primary" type="submit">
                    Remove Post
                  </button>
                </form>
              </Card.Body>
            </Card>
          </ol>
        );
      });
    }
  }

  return (
    <div>
      <br></br>
      <div
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <Button as={Link} to="/new-post">
          Upload Image
        </Button>
      </div>

      <br></br>
      <br></br>
      {body}
    </div>
  );
};

export default MyPost;
