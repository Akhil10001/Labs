const ErrorPage = () => {
  return (
    <div>
      <br></br>
      <h1>PageNotFound: 404</h1>
    </div>
  );
};

export default ErrorPage;
