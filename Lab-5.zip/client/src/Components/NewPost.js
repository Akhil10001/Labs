import { UPLOAD_IMAGE, USER_POSTED_IMAGE } from "../queries";
import { useMutation } from "@apollo/client";
import { useNavigate } from "react-router-dom";

import imageExists from "image-exists";

const NewPost = () => {
  let url, posterName, description;

  const navigate = useNavigate();

  const [newPost] = useMutation(UPLOAD_IMAGE, {
    refetchQueries: [{ query: USER_POSTED_IMAGE }],
  });

  return (
    <div
      style={{
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        height: "60vh",
      }}
    >
      <form
        onSubmit={(e) => {
          e.preventDefault();

          imageExists(url.value, (image) => {
            if (image) {
              if (!isNaN(posterName.value)) {
                alert("Please enter valid posterName");
              } else if (!isNaN(description.value)) {
                alert("Please enter valid description");
              } else {
                newPost({
                  variables: {
                    url: url.value,
                    posterName: posterName.value,
                    description: description.value,
                  },
                });

                alert("photo uploaded");

                navigate("/my-posts");

                /*  url.value='';
                posterName.value=''; 
                description.value='' */
              }
            } else {
              alert("Please enter valid image url");
            }
          });
        }}
      >
        <div className="form-group">
          <label>
            Image URL :
            <br />
            <input
              ref={(node) => {
                url = node;
              }}
              required
              autoFocus={true}
            />
          </label>
        </div>
        <br />
        <div className="form-group">
          <label>
            Description :
            <br />
            <input
              ref={(node) => {
                description = node;
              }}
              required
            />
          </label>
        </div>
        <br />
        <div className="form-group">
          <label>
            Poster Name :
            <br />
            <input
              ref={(node) => {
                posterName = node;
              }}
              required
            />
          </label>
        </div>

        <br></br>
        <div
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <button className="btn btn-primary" type="submit">
            Upload
          </button>
        </div>
      </form>
    </div>
  );
};

export default NewPost;
