import { useQuery } from "@apollo/client";
import { useState } from "react";
import { GET_IMAGES } from "../queries";
import Image from "./Image";
import { Card } from "react-bootstrap";
import "bootstrap/dist/css/bootstrap.min.css";

const Home = () => {
  let list;

  const [pageNum, setPageNum] = useState(1);

  const { data, loading, error } = useQuery(GET_IMAGES, {
    variables: { pageNum: pageNum },
  });

  const getMore = () => {
    setPageNum(pageNum + 1);
  };

  if (loading) {
    return <p>Loading....</p>;
  }

  if (error) {
    return <p>Something went wrong...!</p>;
  }

  if (data) {
    list = data.unsplashImages.map((image) => {
      return (
        <ol key={image.id}>
          <Card style={{ width: "20rem" }}>
            <Card.Img alt={image.id} src={image.url} />
            <Card.Body>
              <Card.Title>Poster name: {image.posterName}</Card.Title>
              <Card.Text>{image.description}</Card.Text>
              <Image image={image} />
            </Card.Body>
          </Card>
        </ol>
      );
    });
  }

  return (
    <div>
      <br></br>
      <br></br>
      <br></br>

      {list}

      <br></br>

      <div
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <button className="btn btn-primary" onClick={() => getMore()}>
          Get More
        </button>
      </div>
    </div>
  );
};

export default Home;
