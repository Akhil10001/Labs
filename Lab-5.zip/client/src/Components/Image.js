import React from "react";
import { useQuery, useMutation } from "@apollo/client";
import { UPDATE_IMAGE, BINNED_IMAGES } from "../queries";

const Image = (props) => {
  let images = props.image;

  let addToBin = true;

  const [updateImage] = useMutation(UPDATE_IMAGE, {
    refetchQueries: [{ query: BINNED_IMAGES }],
  });

  const { loading, error, data } = useQuery(BINNED_IMAGES);

  if (loading) {
    return <p>Loading....</p>;
  } else if (error) {
    return <p>Something went wrong...!</p>;
  } else {
    data.binnedImages.map((image) => {
      if (images.id == image.id) {
        addToBin = false;
      }

      return null;
    });
  }
  let button = addToBin ? "Add to Bin" : "Remove from Bin";
  return (
    <div>
      <form
        onSubmit={(e) => {
          e.preventDefault();

          updateImage({
            variables: {
              id: images.id,
              url: images.url,
              posterName: images.posterName,
              description: images.description,
              userPosted: images.userPosted,
              binned: addToBin,
              numBinned: images.numBinned,
            },
          });

          if (addToBin) alert("saved");
          else alert("removed");
        }}
      >
        <button className="btn btn-primary" type="submit">
          {button}
        </button>
      </form>
    </div>
  );
};

export default Image;
