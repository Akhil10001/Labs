import { useMutation, useQuery } from "@apollo/client"
import { BINNED_IMAGES, UPDATE_IMAGE } from "../queries"

import {Card} from 'react-bootstrap';

const Bin=()=>{


let list;

const[binnedImage]=useMutation(UPDATE_IMAGE, {refetchQueries:[{query:BINNED_IMAGES}]})


const {data,loading,error}=useQuery(BINNED_IMAGES)





if(loading)
{
    return(<p>Loading....</p>)

}

else if(error)
{

    return(<p>Something went wrong...!</p>)    
}
    
else if(data)
{

        if(data.binnedImages)
        {
        

             list=data.binnedImages.map((image)=>{ 


                return(
        
                    <ol key={image.id}>
        
                    <Card style={{ width: '20rem' }}>
                      <Card.Img alt={image.id} src={image.url} />
                      <Card.Body>
                        <Card.Title>poster name: {image.posterName}</Card.Title>
                        <Card.Text>
                          {image.description}
                        </Card.Text>
        
                       <form onSubmit={
        
                           (e)=>{
                               e.preventDefault()
        
                           binnedImage({ variables:{id:image.id,
                            url:image.url,
                            posterName:image.posterName,
                            description:image.description,
                            userPosted:image.userPosted,
                            binned:false,
                            numBinned:image.numBinned
                        }})
        
                           alert('removed')
                           }
                       }>
        
        
                        <button className="btn btn-primary" type="submit">
                            Remove from Bin 
                            
                        </button>
        
                       </form>
                       </Card.Body>
                    </Card>
                    </ol>
                       
        
                )
        
                })


        }




}

     

    return(<div>
        
        <br></br>
        <br></br>
        <br></br>
        
        {list}

    </div>)






}





export default Bin