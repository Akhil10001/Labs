import React from "react";
import { LIKED_IMAGES } from "../queries";
import { useQuery } from "@apollo/react-hooks";
import { Card } from "react-bootstrap";
import Image from "./Image";

const Popularity = () => {
  let list = [],
    total = 0,
    top;

  const { loading, error, data } = useQuery(LIKED_IMAGES, {
    fetchPolicy: "cache-and-network",
  });

  if (loading) {
    return <p>Loading....</p>;
  }

  if (error) {
    return <p>Something went wrong...!</p>;
  }

  if (data) {
    if (data.getTopTenBinnedPosts) {
      list = data.getTopTenBinnedPosts.map((image) => {
        total = image.numBinned + total;

        return (
          <ol key={image.id}>
            <Card style={{ width: "20rem" }}>
              <Card.Img variant="top" src={image.url} />

              <Card.Body>
                <Card.Title>posterName: {image.posterName}</Card.Title>

                <Card.Text>{image.description}</Card.Text>

                <Card.Text>Likes: {image.numBinned}</Card.Text>

                <Image image={image}></Image>
              </Card.Body>
            </Card>
          </ol>
        );
      });

      if (list.length > 0) {
        if (total < 200) {
          top = <h1>Non-mainstream</h1>;
        } else if (total > 200) {
          top = <h1>Mainstream</h1>;
        }
      }
    }
  }

  return (
    <div>
      <br></br>
      <br></br>
      <br></br>

      <div
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        {top}
      </div>

      <br></br>
      <br></br>

      {list}
    </div>
  );
};

export default Popularity;
