const { ApolloServer, gql } = require("apollo-server");

const client_id = "_-d1lkz0X7xWQDTiFqG6b9592NJj72FRLwrd-2j_r2A";

const uuid = require("uuid");

const redis = require("redis");
const client = redis.createClient();
const bluebird = require("bluebird");
const { default: axios } = require("axios");
bluebird.promisifyAll(redis.RedisClient.prototype);
bluebird.promisifyAll(redis.Multi.prototype);

async function getUnsplashImages(pageNum) {
  const data = await axios.get(
    "https://api.unsplash.com/photos/?client_id=" +
      client_id +
      "&page=" +
      pageNum
  );

  const result = data.data.map((results) => {
    let array = {
      id: results.id,
      url: results.urls.small,
      posterName: results.user.name,
      description: results.description,
      userPosted: false,
      binned: false,
      numBinned: results.likes,
    };

    return array;
  });

  return result;
}

async function getUserPostedImages() {
  let postedData = await client.lrangeAsync("uploadedImages", 0, -1);

  const postedImages = postedData.map((img) => {
    return JSON.parse(img);
  });

  return postedImages;
}

async function getBinnedImages() {
  let binnedData = await client.smembersAsync("binnedImages");

  const binnedImages = binnedData.map((img) => {
    return JSON.parse(img);
  });

  return binnedImages;
}

async function updateImage(
  id,
  url,
  posterName,
  description,
  userPosted,
  binned,
  numBinned
) {
  try {
    if (!id) {
      throw "ID is not provided";
    }

    let updatedImage = {
      id,
      url,
      posterName,
      description,
      userPosted,
      binned,
      numBinned,
    };

    let binnedData = await client.smembersAsync("binnedImages");

    const binnedImages = binnedData.map((img) => {
      return JSON.parse(img);
    });

    const binnedImage = binnedImages.find((img) => img.id == id);

    let uploadedData = await client.lrangeAsync("uploadedImages", 0, -1);

    const uploadedImages = uploadedData.map((img) => {
      return JSON.parse(img);
    });

    const uploadedImage = uploadedImages.find((img) => img.id == id);

    if (binnedImage != undefined) {
      if (binnedImage.binned != binned) {
        await client.sremAsync("binnedImages", JSON.stringify(binnedImage));

        if (uploadedImage != undefined) {
          await client.lremAsync(
            "uploadedImages",
            0,
            JSON.stringify(uploadedImage)
          );

          uploadedImage.binned = false;

          await client.lpush("uploadedImages", JSON.stringify(uploadedImage));
        }
      }
    } else if (binned == true) {
      await client.sadd("binnedImages", JSON.stringify(updatedImage));

      if (uploadedImage != undefined) {
        await client.lremAsync(
          "uploadedImages",
          0,
          JSON.stringify(uploadedImage)
        );

        uploadedImage.binned = true;

        await client.lpush("uploadedImages", JSON.stringify(uploadedImage));
      }
    }

    return updatedImage;
  } catch (e) {
    console.log(e);
  }
}

async function uploadImage(url, description, posterName) {
  try {
    if (!url) {
      throw "url is not provided";
    } else if (typeof url != "string") {
      throw "url is not a string";
    }

    let uploadImage = {
      id: uuid(),
      url,
      posterName,
      description,
      userPosted: true,
      binned: false,
      numBinned: -1,
    };

    await client.lpush("uploadedImages", JSON.stringify(uploadImage));

    return uploadImage;
  } catch (e) {
    console.log(e);
  }
}

async function deleteImage(id) {
  try {
    if (!id) {
      throw "ID is not provided";
    }

    let postedData = await client.lrangeAsync("uploadedImages", 0, -1);

    const postedImages = postedData.map((img) => {
      return JSON.parse(img);
    });

    const postedImage = postedImages.find((img) => img.id == id);

    let binnedData = await client.smembersAsync("binnedImages");

    const binnedImages = binnedData.map((img) => {
      return JSON.parse(img);
    });

    const binnedImage = binnedImages.find((img) => img.id == id);

    if (postedImage != undefined) {
      await client.lremAsync("uploadedImages", 0, JSON.stringify(postedImage));

      if (binnedImage != undefined) {
        await client.sremAsync("binnedImages", JSON.stringify(binnedImage));
      }
    }
  } catch (e) {
    console.log(e);
  }
}

async function getTopTenBinnedPosts() {
  let likedImages = [];

  let binnedData = await client.smembersAsync("binnedImages");

  const binnedImages = binnedData.map((img) => {
    return JSON.parse(img);
  });

  for (let image of binnedImages) {
    if (image.numBinned >= 0) {
      likedImages.push(image);
    }
  }

  likedImages.sort((a, b) => {
    return b.numBinned - a.numBinned;
  });

  return likedImages.slice(0, 10);
}

const typeDefs = gql`
  type ImagePost {
    id: ID!
    url: String!
    posterName: String!
    description: String
    userPosted: Boolean!
    binned: Boolean!
    numBinned: Int!
  }

  type Query {
    unsplashImages(pageNum: Int): [ImagePost]
    binnedImages: [ImagePost]
    userPostedImages: [ImagePost]
    getTopTenBinnedPosts: [ImagePost]
  }

  type Mutation {
    uploadImage(
      url: String!
      description: String
      posterName: String
    ): ImagePost
    updateImage(
      id: ID!
      url: String
      posterName: String
      description: String
      userPosted: Boolean
      binned: Boolean
      numBinned: Int
    ): ImagePost
    deleteImage(id: ID!): ImagePost
  }
`;

const resolvers = {
  Query: {
    unsplashImages: async (_, args) => {
      return await getUnsplashImages(args.pageNum);
    },

    userPostedImages: async () => {
      return await getUserPostedImages();
    },

    binnedImages: async () => {
      return await getBinnedImages();
    },

    getTopTenBinnedPosts: async () => {
      return await getTopTenBinnedPosts();
    },
  },

  Mutation: {
    uploadImage: async (_, args) => {
      return await uploadImage(args.url, args.description, args.posterName);
    },

    updateImage: async (_, args) => {
      return await updateImage(
        args.id,
        args.url,
        args.posterName,
        args.description,
        args.userPosted,
        args.binned,
        args.numBinned
      );
    },

    deleteImage: async (_, args) => {
      return await deleteImage(args.id);
    },
  },
};

const server = new ApolloServer({
  typeDefs,
  resolvers,
});

server.listen().then(({ url }) => {
  console.log(`🚀  Server ready at ${url} 🚀`);
});
